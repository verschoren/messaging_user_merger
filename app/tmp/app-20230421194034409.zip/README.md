# Zendesk Messaging Profile Fixer

This application is a proof of concept for an app that merges or fixes orphaned Messaging Profiles.
See https://internalnote.com/deepdive-into-messaging-profiles/